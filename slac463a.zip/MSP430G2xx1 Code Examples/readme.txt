Please beware that different variants of the G2xx1 devices have different peripheral sets. 
Therefore certain peripheral examples are only applicable to certain devices, as follows.
ADC10 code examples applicable for G2x31 devices
COMP_A+ code examples applicable for G2x11 devices
USI code examples applicable for G2x21 & G2x31 devices


